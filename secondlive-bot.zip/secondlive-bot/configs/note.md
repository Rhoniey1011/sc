### make file config.json in the same directory

### Example format

```json
[
  {
    "token": "eyJh"
  },
  {
    "token": "eyJh"
  }
]
```
